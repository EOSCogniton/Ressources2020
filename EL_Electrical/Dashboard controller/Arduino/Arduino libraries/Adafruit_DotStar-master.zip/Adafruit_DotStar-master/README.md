# Adafruit DotStar Library [![Build Status](https://travis-ci.com/adafruit/Adafruit_DotStar.svg?branch=master)](https://travis-ci.com/adafruit/Adafruit_DotStar)

Arduino library for controlling two-wire-based LED pixels and strips such as Adafruit DotStar LEDs and other APA102-compatible devices.
